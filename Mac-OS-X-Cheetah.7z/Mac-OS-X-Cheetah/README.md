# Mac OS Cheetah Theme for Linux

Mac OS theme with the Aqua design guidelines

![mac-os-x-10](http://b00merang.weebly.com/uploads/1/6/8/1/16813022/capture-du-2017-06-04-21-08-52_orig.png)

**Maintainer:** [Elbullazul](https://github.com/elbullazul)

**Distributor:** [B00merang Project](https://github.com/B00merang-Project)

**License:** GPL v3

**More info :** http://b00merang.weebly.com/mac-os-x-cheetah.html

***

> Installation instructions : http://b00merang.weebly.com/easy-installation-guide.html
